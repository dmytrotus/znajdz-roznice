<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gamer extends Model
{
   	protected $fillable = ['nick', 'time'];
}
